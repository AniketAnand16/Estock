package com.example.EStockMarketApplication.Consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class StockConsumer
{
    @KafkaListener(topics="kafka", groupId="kafkagroup")
    public void consumeFromTopic(String message)

    {
        System.out.println("Message from User Service:  "+ message);

    }

}